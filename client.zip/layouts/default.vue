<template>
    <div id="layout" class="layout-demo">
            <Navigation />
        <slot></slot>
        <Footer />
    </div>
</template>
<script setup>
</script>
